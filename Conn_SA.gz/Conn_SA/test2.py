f = "line_all"



with open("line_all") as f:
	for line in f:
		parts = line.split()
		if parts[1] != '3024':
			print(line)
