import numpy as np

f = "sio_all"
d = np.genfromtxt(f, usecols = 0, unpack = True)
d.tolist()
print(len(d))

for i in range(len(d)):
	if d[i] >= 2.3:
		print(d[i])
		#print(d[i], d.index(d[i]))
